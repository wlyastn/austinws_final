/*
main.h
Written by William Hoskins
*/

#pragma once

#include "fib.h"
